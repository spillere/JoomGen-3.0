<?php
/**
 * Posts HTML List Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>

<h1><?php echo JText::_('Posts'); ?></h1>
<?php if(count($this->items) > 0) : ?>
<div id="posts_list">
    <p><?php echo JText::_('Below is a list of all current Posts'); ?>.</p>
    <table border="0" cellspacing="1" cellpadding="1">
    <thead>
        <tr>
            <th><?php echo JText::_('Title'); ?></th>
            <th><?php echo JText::_('Author'); ?></th>

        </tr>
    </thead>

    <?php foreach ($this->items as $item) : ?>
    <?php $link = JRoute::_('index.php?option=com_blog&amp;view=posts&amp;layout=details&amp;id='.$item->id); ?>
        <tr>
            <td><?php echo "<a href='$link'>".$item->title."</a>"; ?></td>
            <td><?php echo "<a href='$link'>".$item->author_name."</a>"; ?></td>

        </tr>
    <?php endforeach; ?>
    </table>
<?php else: ?>
    <p><?php echo JText::_('No Posts found'); ?>.</p>
<?php endif; ?>
</div>