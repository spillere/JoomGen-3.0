<?php
/**
 * Posts HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
JHTML::_('behavior.formvalidation');
JHTML::_('behavior.keepalive');

$editor =& JFactory::getEditor();
$params = array('smilies'=> '0', 'html' => '1', 'style'  => '1', 'layer'  => '0', 'table'  => '1', 'clear_entities'=>'0');
?>

<h1><?php echo JText::_('Add Posts'); ?></h1>
<form id="new_posts" name="new_posts" method="post" onsubmit="return document.formvalidator.isValid(this)">
<table border="0" cellspacing="1" cellpadding="1">
            <tr>
                <td width="100" align="right" class="key"><label for="title"> <?php echo JText::_('Title'); ?>:</label></td>
                <td><input class="text_area" type="text" name="title" id="title" size="32" maxlength="250" value="<?php echo $this->item->title;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="alias"> <?php echo JText::_('Alias'); ?>:</label></td>
                <td><input class="text_area" type="text" name="alias" id="alias" size="32" maxlength="250" value="<?php echo $this->item->alias;?>" /></td>
            </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="content"> <?php echo JText::_('Content'); ?>:</label></td>
                <td><?php echo $editor->display('content', $this->item->content, '400', '400', '20', '20', false, $params); ?></td>
        </tr>
            <tr>
                <td width="100" align="right" class="key"><label for="author_name"> <?php echo JText::_('Author'); ?>:</label></td>
                <td><input class="text_area" type="text" name="author_name" id="author_name" size="32" maxlength="250" value="<?php echo $this->item->author_name;?>" /></td>
            </tr>

</table>
    <?php echo JHTML::_('form.token'); ?>
    <input type="submit" value="<?php echo JText::_('Submit'); ?>" />
    <input type="hidden" name="option" value="com_blog" />
    <input type="hidden" name="task" value="save" />
    <input type="hidden" name="view" value="posts" />
    <input type="hidden" name="controller" value="posts" />
</form>