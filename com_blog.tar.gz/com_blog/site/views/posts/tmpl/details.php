<?php
/**
 * Posts HTML Details Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>

<?php if($this->item->id > 0) : ?>
<table border="0" cellspacing="1" cellpadding="1">
<tr>
    <th><?php echo JText::_('Title'); ?></th>
    <td><?php echo $this->item->title; ?></td></tr>
<tr>
    <th><?php echo JText::_('Content'); ?></th>
    <td><?php echo $this->item->content; ?></td></tr>
<tr>
    <th><?php echo JText::_('Author'); ?></th>
    <td><?php echo $this->item->author_name; ?></td></tr>

</table>
<?php else : ?>
    <p><?php echo JText::_('Posts not found'); ?>.</p>
<?php endif; ?>