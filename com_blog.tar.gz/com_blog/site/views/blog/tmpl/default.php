<?php
/**
 * HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
?>
<ul><li><a href="<?php echo JRoute::_('index.php?option=com_blog&view=posts&layout=details'); ?>">Posts Details</a></li><li><a href="<?php echo JRoute::_('index.php?option=com_blog&view=posts&layout=new'); ?>">Posts New</a></li><li><a href="<?php echo JRoute::_('index.php?option=com_blog&view=posts&layout=list'); ?>">Posts List</a></li></ul>