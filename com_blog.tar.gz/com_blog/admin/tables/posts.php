<?php
/**
 * Posts Table Class
 *
 * PHP versions 5
 *
 * @category  Table_Class
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is within the rest of the framework
defined('_JEXEC') or die('Restricted access');

/**
 * Posts Table Class
 *
 * @category  Table_Class
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @version   1.0.0
 */
class JTablePosts extends JTable
{
    /**
     * @var int Primary key
     */
    var $id = null;
    
    /**
     * @var string Title
     */
    var $title = '';

    /**
     * @var string Alias
     */
    var $alias = '';

    /**
     * @var rich_text Content
     */
    var $content = '';

    /**
     * @var string Author
     */
    var $author_name = '';

    /**
     * @var datetime Created On
     */
    var $created_on = null;

    /**
     * @var bool Published
     */
    var $published = 0;

    /**
     * Constructor
     *
     * @param object &$db A database connector object
     *
     * @return void
     * @access public
     * @since  1.0
     */
    public function __construct(&$db)
    {
        parent::__construct('#__blog_posts', 'id', $db);
    }

    /**
     * Overloaded check function
     *
     * @return boolean
     * @access public
     * @since  1.0
     * @see    JTable::check
     */
    public function check()
    {
        // check required fields
        $required_fields = array('title' => 'Title', 'content' => 'Content', 'author_name' => 'Author', 'created_on' => 'Created On');
        foreach($required_fields as $field => $description) {
            if(!$this->get($field)) {
                $this->setError(JText::_($description.' is required.'));
                return false;
            }
        }

        return true;
    }
}
?>
