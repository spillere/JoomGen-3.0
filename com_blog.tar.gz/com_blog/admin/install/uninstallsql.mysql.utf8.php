DROP TABLE IF EXISTS `#__blog_posts`;
DROP TABLE IF EXISTS `#__blog_categories`;
