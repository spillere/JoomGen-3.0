<?php
/**
 * Categories HTML Default Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');


?>

<form action="index.php" method="post" name="adminForm" id="adminForm">
    <div class="col100">
        <fieldset class="adminform"><legend><?php echo JText::_(''); ?></legend>
        <table class="admintable">
            <tr>
                <td width="100" align="right" class="key"><label for="title"> <?php echo JText::_('Title'); ?>:</label></td>
                <td><input class="text_area" type="text" name="title" id="title" size="32" maxlength="250" value="<?php echo $this->item->title;?>" /></td>
            </tr>

            <tr></tr>
        </table>
        </fieldset>
    </div>

    <div class="clr"></div>

    <input type="hidden" name="option" value="com_blog" />
    <input type="hidden" name="id" value="<?php echo $this->item->id; ?>" />
    <input type="hidden" name="view" value="categories" />
    <input type="hidden" name="controller" value="categories" />
    <input type="hidden" name="task" value="save" />
</form>
