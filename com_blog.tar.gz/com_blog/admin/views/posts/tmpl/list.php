<?php
/**
 * Posts HTML List Template
 *
 * PHP versions 5
 *
 * @category  Template
 * @package   Blog
 * @author    Rodrigo Spillere <rodrigo@jetworks.com.br>
 * @copyright 2010 JetWorks. All rights reserved.
 * @license   GNU General Public License
 * @link      http://jetworks.com.br
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die('Restricted access');
jimport('joomla.filter.filteroutput');
?>

<table class="adminform"><tr><td>
<div id="posts">
    <form action="index.php" method="post" name="adminForm" id="adminForm">
    <div id="editcell">
        <table class="adminlist">
        <thead>
            <tr>
                <th width="5"><?php echo JText::_('ID'); ?></th>
                <th width="20"><input type="checkbox" name="toggle" value="" onclick="checkAll(<?php echo count($this->items); ?>);" /></th>
                  <th><?php echo JText::_('Title'); ?></th>
                  <th><?php echo JText::_('Alias'); ?></th>
                  <th><?php echo JText::_('Content'); ?></th>
                  <th><?php echo JText::_('Author'); ?></th>
                  <th><?php echo JText::_('Created On'); ?></th>
                  <th><?php echo JText::_('Published'); ?></th>

            </tr>
        </thead>
        <?php
            $k = 0;
            $i = 0;
            foreach($this->items as $row)
            {
                JFilterOutput::objectHTMLSafe($row);
                $checked = JHTML::_('grid.id', $i, $row->id);
                $link = JRoute::_('index.php?option=com_blog&view=posts&task=edit&cid[]='. $row->id);
        ?>
                <tr class="<?php echo "row$k"; ?>">
                    <td><?php echo $row->id; ?></td>
                    <td><?php echo $checked; ?></td>
                       <td><?php echo "<a href='$link'>".$row->title."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->alias."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->content."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->author_name."</a>"; ?></td>
                       <td><?php echo "<a href='$link'>".$row->created_on."</a>"; ?></td>
                       <td><?php echo JHTML::_('grid.published', $row, $i); ?></td>

                </tr>
        <?php
                $k = 1 - $k;
                $i = $i + 1;
            }
        ?>
        </table>
    </div>
    <input type="hidden" name="option" value="com_blog" />
    <input type="hidden" name="task" value="" />
    <input type="hidden" name="boxchecked" value="0" />
    <input type="hidden" name="view" value="posts" />
    <input type="hidden" name="controller" value="posts" />
</form>
</div>
</td></tr></table>
